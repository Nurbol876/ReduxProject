import React, { useEffect, useState } from "react";
import {useDispatch, useSelector} from "react-redux";
import { getData} from "./redux/reducers/tasks";
import { collection, getDocs } from "firebase/firestore";
import { db } from "./firebase";

function App() {
    const [search, setSearch] = useState(""); // Поле поиска
    const tasks = useSelector((s) => s.tasks.tasks)
    const cntTasks = useSelector((s) => s.tasks.tasksCount)
    const dispatch = useDispatch();

    const fetchTasks = async () => {
        try {
            const querySnapshot = await getDocs(collection(db, "tasks"));
            const loadedTasks = querySnapshot.docs.map((doc) => ({
                ...doc.data(),
                id: doc.id,
            }));
            dispatch(getData(loadedTasks));
        } catch (error) {
            console.error("Ошибка загрузки задач:", error);
        }
    };

    useEffect(() => {
        fetchTasks();
    }, []);

    return (
        <div className="App">
            {/*<form*/}
            {/*    onSubmit={(e) => {*/}
            {/*        e.preventDefault();*/}
            {/*        const taskName = e.target[0].value;*/}
            {/*        const taskTime = e.target[1].value;*/}
            {/*        if (taskName.trim() && taskTime.trim()) {*/}
            {/*            dispatch(addTask(taskName, taskTime));*/}
            {/*            e.target[0].value = "";*/}
            {/*            e.target[1].value = "";*/}
            {/*        }*/}
            {/*    }}*/}
            {/*>*/}
            {/*    <input type="text" placeholder="Задача" />*/}
            {/*    <input type="time" />*/}
            {/*    <button type="submit">Добавить</button>*/}
            {/*</form>*/}
            {/*<button*/}
            {/*    onClick={(e) => {*/}
            {/*        e.preventDefault();*/}
            {/*        dispatch(deleteAll());*/}
            {/*        setTasks([]);*/}
            {/*    }}*/}
            {/*>*/}
            {/*    Удалить все*/}
            {/*</button>*/}

            {/*/!* Таблица задач *!/*/}
            <h2>There is {cntTasks} tasks</h2>
                <table>
                    <tr>
                        <td>ID</td>
                        <td>Время</td>
                        <td>Задача</td>
                        <td>Дата</td>
                    </tr>
                {tasks
                    .filter((task) =>
                        task.task.toLowerCase().includes(search.toLowerCase())
                    )
                    .map((task) => (
                        <tr key={task.id}>
                            <td>{task.number}</td>
                            <td>{task.time}</td>
                            <td>{task.task}</td>
                            <td>{task.day}-{task.month}</td>
                            {/*<td>*/}
                            {/*    <button*/}
                            {/*        onClick={(e) => {*/}
                            {/*            e.preventDefault();*/}
                            {/*            dispatch(deleteTask(task.id));*/}
                            {/*            setTasks(tasks.filter((t) => t.id !== task.id)); // Удаляем из локального состояния*/}
                            {/*        }}*/}
                            {/*    >*/}
                            {/*        Удалить*/}
                            {/*    </button>*/}
                            {/*</td>*/}
                        </tr>
                    ))}</table>
            <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                type="text"
                placeholder="Поиск задач"
            />
        </div>
    );
}

export default App;
